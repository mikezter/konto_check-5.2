/* 
vim:cindent:ft=c:foldmethod=marker:fmr=+���,-���
*/

/* Code-Beispiel und Definitionen f�r konto_check unter Visual C#.net +���1
 *
 * Die Schnittstelle benutzt einige DLL-Einsprungpunkte die erst ab Version 4.0
 * von konto_check verf�gbar sind (kc_alloc() in iban2bic() und ipi_gen() sowie
 * kto_check_idx2blz() in den Suchroutinen). Daher ist sie mit den
 * DLL-Versionen 3.x nur eingeschr�nkt nutzbar.
 *
 * Die main() Routine ist die von mini.cs; sie nimmt als Eingabe eine Datei mit
 * einer Liste von BLZ/Kontonummer-Paaren (durch Blank getrennt). Diese werden
 * auf G�ltigkeit testet und das Ergebnis in eine Ausgabedatei geschrieben. Es
 * wird nur ein kleiner Teil der Definitionen benutzt.
 */

/* Copyright-Notiz +���3
 * ##########################################################################
 * #  Dies ist die Schnittstelle f�r Visual C#.net zu konto_check, sowie    #
 * #  ein kleines Code-Beispiel f�r die Verwendung einzelner Routinen.      #
 * #                                                                        #
 * #  Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>           #
 * #                                                                        #
 * #  Dieses Programm ist freie Software; Sie d�rfen es unter den           #
 * #  Bedingungen der GNU Lesser General Public License, wie von der Free   #
 * #  Software Foundation ver�ffentlicht, weiterverteilen und/oder          #
 * #  modifizieren; entweder gem�� Version 2.1 der Lizenz oder (nach Ihrer  #
 * #  Option) jeder sp�teren Version.                                       #
 * #                                                                        #
 * #  Die GNU LGPL ist weniger infekti�s als die normale GPL; Code, der von #
 * #  Ihnen hinzugef�gt wird, unterliegt nicht der Offenlegungspflicht      #
 * #  (wie bei der normalen GPL); au�erdem m�ssen Programme, die diese      #
 * #  Bibliothek benutzen, nicht (L)GPL lizensiert sein, sondern k�nnen     #
 * #  beliebig kommerziell verwertet werden. Die Offenlegung des Sourcecodes#
 * #  bezieht sich bei der LGPL *nur* auf ge�nderten Bibliothekscode.       #
 * #                                                                        #
 * #  Dieses Programm wird in der Hoffnung weiterverbreitet, da� es         #
 * #  n�tzlich sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die    #
 * #  implizierte Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R       #
 * #  EINEN BESTIMMTEN ZWECK. Mehr Details finden Sie in der GNU Lesser     #
 * #  General Public License.                                               #
 * #                                                                        #
 * #  Sie sollten eine Kopie der GNU Lesser General Public License          #
 * #  zusammen mit diesem Programm erhalten haben; falls nicht,             #
 * #  schreiben Sie an die Free Software Foundation, Inc., 59 Temple        #
 * #  Place, Suite 330, Boston, MA 02111-1307, USA. Sie k�nnen sie auch     #
 * #  von                                                                   #
 * #                                                                        #
 * #       http://www.gnu.org/licenses/lgpl.html                            #
 * #                                                                        #
 * # im Internet herunterladen.                                             #
 * ##########################################################################
 */

/* Using-Direktiven +���3 */
using System;
using System.IO;
using System.Runtime.InteropServices;
/* -���3 */

namespace mini
{
   class Program
   {
/* Entrypoints der DLL-Funktionen +���2 */
#region Externals

         /* In diesem Teil sind nur die DLL-Einsprungpunkte definiert. Eine
          * kurze Beschreibung der einzelnen Funktionen findet sich unten bei
          * der Definition der einzelnen Funktionen.
          */

         /* Allgemeine Funktionen +���3 */
#region Allgemeine Funktionen
         /* Entrypoint kto_check_idx2blz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_idx2blz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 kto_check_idx2blz(Int32 idx, out Int32 zweigstelle, out Int32 retval);

         /* Entrypoint kto_check_encoding +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_encoding", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 kto_check_encoding_i(Int32 encoding);

         /* Entrypoint kto_check_init_p +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_init_p", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 kto_check_init_i(String lutName, Int32 required, Int32 set, Int32 incremental);

         /* Entrypoint current_lutfile_name +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "current_lutfile_name", CallingConvention = CallingConvention.Cdecl)]
         private static extern IntPtr current_lutfile_name_i(out Int32 set, out Int32 level, out Int32 retval);

         /* Entrypoint kto_check_blz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_blz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 kto_check_blz(String blz, String kto);

         /* Entrypoint kto_check_pz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_pz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 kto_check_pz(String pz, String kto, String blz);

         /* Entrypoint kto_check_retval2txt +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_retval2txt", CallingConvention=CallingConvention.Cdecl)]
         private static extern IntPtr kto_check_retval2txt(Int32 retval);

         /* Entrypoint kto_check_retval2txt_short +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kto_check_retval2txt_short", CallingConvention=CallingConvention.Cdecl)]
         private static extern IntPtr kto_check_retval2txt_short(Int32 retval);

         /* Entrypoint cleanup_kto +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "cleanup_kto", CallingConvention=CallingConvention.Cdecl)]
         private static extern void cleanup_kto();

         /* Entrypoint kc_alloc +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kc_alloc", CallingConvention=CallingConvention.Cdecl)]
         private static extern IntPtr kc_alloc(Int32 size,out Int32 retval);

         /* Entrypoint kc_free +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "kc_free", CallingConvention=CallingConvention.Cdecl)]
         private static extern void kc_free(IntPtr ptr);

         /* IBAN-Funktionen +���3 */
         /* Entrypoint iban2bic +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "iban2bic", CallingConvention=CallingConvention.Cdecl)]
         private static extern IntPtr iban2bic_i(String iban, out Int32 retval,IntPtr blz,IntPtr kto);

         /* Entrypoint iban_gen +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "iban_bic_gen1", CallingConvention=CallingConvention.Cdecl)]
         private static extern IntPtr iban_gen_i(String blz, String kto, out IntPtr bic, out Int32 retval);

         /* Entrypoint ci_check +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "ci_check", CallingConvention=CallingConvention.Cdecl)]
         private static extern Int32 ci_check_i(String ci);

         /* Entrypoint iban_check +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "iban_check", CallingConvention=CallingConvention.Cdecl)]
         private static extern Int32 iban_check_i(String iban, out Int32 retval);

         /* Entrypoint ipi_gen +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "ipi_gen", CallingConvention=CallingConvention.Cdecl)]
         private static extern Int32 ipi_gen_i(String zweck, out IntPtr dst, out IntPtr papier);

         /* Entrypoint ipi_check +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "ipi_check", CallingConvention=CallingConvention.Cdecl)]
         private static extern Int32 ipi_check(String ipi);
#endregion

         /* Suchfunktionen +���3 */
#region Suchfunktionen
         /* Entrypoint lut_suche_bic +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_bic", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_bic(String such_name, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_namen +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_namen", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_namen(String such_name, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_namen_kurz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_namen_kurz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_namen_kurz(String such_name, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_ort +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_ort", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_ort(String such_name, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_plz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_plz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_plz(Int32 such1, Int32 such2, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_blz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_blz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_blz(Int32 such1, Int32 such2, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_pz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_pz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_pz(Int32 such1, Int32 such2, out Int32 anzahl, out IntPtr start_idx, 
               out IntPtr zweigstellen, out IntPtr base_name, out IntPtr blz_base);

         /* Entrypoint lut_suche_volltext +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_volltext", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_volltext(String such_wort, out Int32 anzahl, out Int32 base_name_idx,
               out IntPtr base_name, out Int32 zweigstellen_anzahl, out IntPtr start_idx, out IntPtr zweigstellen_base,
               out IntPtr blz_base);

         /* Entrypoint lut_suche_multiple +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_suche_multiple", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_suche_multiple(String such_str, Int32 uniq, String such_cmd, out Int32 anzahl,
               out IntPtr zweigstellen_base, out IntPtr blz_base);

#endregion

         /* Funktionen f�r die LUT-datei +���3 */
#region Funktionen f�r die LUT-datei
         /* Entrypoint generate_lut2_p +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "generate_lut2_p", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 generate_lut2_p(String inputname,String outputname,String user_info,
               String gueltigkeit,Int32 felder,Int32 filialen,Int32 slots,Int32 lut_version,Int32 set);

         /* Entrypoint lut_keine_iban_berechnung +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_keine_iban_berechnung", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_keine_iban_berechnung_i(String iban_blacklist,String lutfile,Int32 set);

         /* Entrypoint lut_dir_dump_str +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_dir_dump_str", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_dir_dump_str_i(String lutname, out IntPtr dptr);

      /* Entrypoint lut_info +���4 */
   [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_info", CallingConvention = CallingConvention.Cdecl)]
      private static extern Int32 lut_info_i(String lutname,out IntPtr info1,out IntPtr info2,out Int32 valid1,out Int32 valid2);

         /* Entrypoint lut_blz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_blz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_blz(String blz, Int32 zweigstelle);

         /* Entrypoint lut_filialen +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_filialen", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_filialen(String blz, out Int32 retval);

         /* Entrypoint lut_name +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_name", CallingConvention = CallingConvention.Cdecl)]
         private static extern IntPtr lut_name(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_name_kurz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_name_kurz", CallingConvention = CallingConvention.Cdecl)]
         private static extern IntPtr lut_name_kurz(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_plz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_plz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_plz(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_ort +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_ort", CallingConvention = CallingConvention.Cdecl)]
         private static extern IntPtr lut_ort(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_pan +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_pan", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_pan(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_bic +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_bic", CallingConvention = CallingConvention.Cdecl)]
         private static extern IntPtr lut_bic(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_nr +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_nr", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_nr(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_pz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_pz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_pz(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_aenderung +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_aenderung", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_aenderung(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_loeschung +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_loeschung", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_loeschung(String blz, Int32 zweigstelle, out Int32 retval);

         /* Entrypoint lut_nachfolge_blz +���4 */
      [DllImport("konto_check.cdecl.dll", EntryPoint = "lut_nachfolge_blz", CallingConvention = CallingConvention.Cdecl)]
         private static extern Int32 lut_nachfolge_blz(String blz, Int32 zweigstelle, out Int32 retval);

#endregion
#endregion

#region kc_defs
/* C#-Definitionen: Allgemeine Funktionen +���2 */
#region allgemeine Funktionen
         /* Funktion kto_check_init() +���3 */
#region kto_check_init()
         /* Die Funktion kto_check_init() initialisiert die Bibliothek mit den
          * Werten aus einer LUT-Datei. Die Parameter sind alle optional, da in
          * der konto_check Bibliothek viele Defaultwerte vorgegeben sind, die
          * normalerweise ausreichen. Die Parameter haben die folgende Bedeutung:
          *
          * lutfile:      Die Datei aus der gelesen werden soll. Defaultwerte
          *               sind dabei f�r den Dateipfad (in dieser Reihenfolge)
          *               ".","C:","C:\\Programme\\konto_check"
          *               und f�r den Dateinamen "blz.lut","blz.lut2f","blz.lut2".
          *               Die Werte k�nnen in der Datei konto_check.h beliebig
          *               ver�ndert werden.
          *
          * required:     (Integerwert zwischen 0 und 9). Gibt an, welche BLocks
          *               geladen werden sollen; Default ist 7. Eine Liste der
          *               geladenen Blocks findet sich im Anhang der Datei
          *               00liesmich.pdf.
          *
          * set:          (Integer, 0, 1 oder 2). In einer LUT-Datei k�nnen zwei
          *               Datens�tze enthalten sein; dieser Parameter bestimmt,
          *               welcher Satz zu laden ist. Bei 0 wird der Datensatz
          *               anhand des Systemdatums und G�ltigkeitszeitraums der
          *               beiden Datens�tze automatisch bestimmt.
          *
          * incremental: falls der Parameter 1 ist, wird eine inkrementelle
          *              Initialisierung (Nachladen von noch nicht geladenen
          *              Blocks) versucht. Diese ist allerdings nur vom selben
          *              Datensatz wie bei der initialen Initialisierung
          *              m�glich.
          */

         /* Funktion kto_check_init() +���4 */
      static Int32 kto_check_init()
      {
         return kto_check_init_i("", 7, 0, 0);
      }
         /* Funktion kto_check_init(Int32 level) +���4 */
      static Int32 kto_check_init(Int32 level)
      {
         return kto_check_init_i("", level, 0, 0);
      }
         /* Funktion kto_check_init(Int32 level, Int32 set) +���4 */
      static Int32 kto_check_init(Int32 level,Int32 set)
      {
         return kto_check_init_i("", level, set, 0);
      }
         /* Funktion kto_check_init(String lutfile) +���4 */
      static Int32 kto_check_init(String lutfile)
      {
         return kto_check_init_i(lutfile, 7, 0, 0);
      }
         /* Funktion kto_check_init(String lutfile, Int32 level) +���4 */
      static Int32 kto_check_init(String lutfile, Int32 level)
      {
         return kto_check_init_i(lutfile, level,0,0);
      }
         /* Funktion kto_check_init(String lutfile, Int32 level, Int32 set) +���4 */
      static Int32 kto_check_init(String lutfile, Int32 level, Int32 set)
      {
         return kto_check_init_i(lutfile, level,set,0);
      }
         /* Funktion kto_check_init(String lutfile, Int32 level, Int32 set, Int32 incremental) +���4 */
      static Int32 kto_check_init(String lutfile, Int32 level, Int32 set, Int32 incremental)
      {
         return kto_check_init_i(lutfile, level, set, incremental);
      }
#endregion

         /* Funktion kto_check_encoding() +���3 */
#region kto_check_encoding()
         /* Die Funktion kto_check_encoding() setzt (bzw. liest) die Kodierung
          * f�r die konto_check Bibliothek. Es kann sowohl die Kodierung f�r
          * die Fehlermeldungen als auch die der LUT-Datei gesetzt werden.
          * Innerhalb der LUT-Datei sind die Werte im Format ISO-8859-1
          * gespeichert; sie werden bei der Initialisierung konvertiert.
          *
          * F�r den Parameter mode werden die folgenden Werte akzeptiert:
          *       1: ISO-8859-1
          *       2: UTF-8
          *       3: HTML-Entities
          *       4: DOS (CP850)
          *      51: Fehlermeldungen als Makronamen, Rest in ISO-8859-1
          *      52: Fehlermeldungen als Makronamen, Rest in UTF-8
          *      53: Fehlermeldungen als Makronamen, Rest in HTML-Entities
          *      54: Fehlermeldungen als Makronamen, Rest in DOS (CP850)
          *
          * R�ckgabewert ist der aktuell gesetzte Modus (als Zahl). Falls die
          * Funktion mit dem Parameter 0 aufgerufen wird, wird nur die aktuelle
          * Kodierung zur�ckgegeben.
          */

         /* Funktion kto_check_encoding() +���4 */
      static Int32 kto_check_encoding()
      {
         return kto_check_encoding_i(0);
      }
         /* Funktion kto_check_encoding(Int32 encoding) +���4 */
      static Int32 kto_check_encoding(Int32 encoding)
      {
         return kto_check_encoding_i(encoding);
      }
#endregion

         /* Funktion current_lutfile_name() +���3 */
#region current_lutfile_name()
         /* Die Funktion liefert den Namen der LUT-Datei von der initialisiert
          * wurde, sowie das benutzte Set und den Initialisierungslevel zur�ck.
          * Die Parameter haben die folgende Bedeutung:
          *
          * set:          Das benutzte Set (1 oder 2), oder 0 falls noch nicht
          *               initialisiert wurde.
          *
          * level:        Der Initialisierungslevel (0...9).
          *
          * retval:       Statuswert; er kann die Werte -40 (noch nicht
          *               initialisiert) oder 1 (OK) annehmen:
          *
          * Der R�ckgabewert ist der Name der LUT-Datei, von der initialisiert
          * wurde.
          */
         /* Funktion current_lutfile_name() +���4 */
      static String current_lutfile_name()
      {
         Int32 set,level,retval;

         return Marshal.PtrToStringAnsi(current_lutfile_name_i(out set,out level,out retval));
      }
         /* Funktion current_lutfile_name(out Int32 set) +���4 */
      static String current_lutfile_name(out Int32 set)
      {
         Int32 level,retval;

         return Marshal.PtrToStringAnsi(current_lutfile_name_i(out set,out level,out retval));
      }
         /* Funktion current_lutfile_name(out Int32 set,out Int32 level) +���4 */
      static String current_lutfile_name(out Int32 set,out Int32 level)
      {
         Int32 retval;

         return Marshal.PtrToStringAnsi(current_lutfile_name_i(out set,out level,out retval));
      }
         /* Funktion current_lutfile_name(out Int32 set,out Int32 level,out Int32 retval) +���4 */
      static String current_lutfile_name(out Int32 set,out Int32 level,out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(current_lutfile_name_i(out set,out level,out retval));
      }
#endregion

         /* Funktion retval2txt() +���3 */
#region retval2txt()

         /* ###########################################################################
          * # Die Funktion kto_check_retval2txt() wandelt die numerischen R�ckgabe-   #
          * # werte in Klartext um. Die Funktion retval2txt_short macht dasselbe,     #
          * # nur mit symbolischen Klartexten (Makronamen).                           #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion retval2txt(Int32 retval) +���4 */
      static String retval2txt(Int32 retval)
      {
         return Marshal.PtrToStringAnsi(kto_check_retval2txt(retval));
      }

         /* Funktion retval2txt_short(Int32 retval) +���4 */
      static String retval2txt_short(Int32 retval)
      {
         return Marshal.PtrToStringAnsi(kto_check_retval2txt_short(retval));
      }
#endregion
#region kto_check_free()

         /* ###########################################################################
          * # Die Funktion kto_check_free() gibt allen benutzten Speicher der         #
          * # konto_check Bibliothek wieder frei.                                     #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion kto_check_free() +���4 */
      static void kto_check_free()
      {
         cleanup_kto();
      }
#endregion
#endregion

/* C#-Definitionen: IBAN-Funktionen +���2 */
#region IBAN-Funktionen
         /* Funktion iban2bic() +���3 */
#region iban2bic()

         /* ###########################################################################
          * # Die Funktion iban2bic extrahiert aus einer IBAN (International Bank     #
          * # Account Number) Kontonummer und Bankleitzahl, und bestimmt zu der BLZ   #
          * # die zugeh�rige BIC. Voraussetzung ist nat�rlich, da� das BIC Feld in    #
          * # der geladenen LUT-Datei enthalten ist. BLZ und Kontonummer werden,      #
          * # falls gew�nscht, in zwei Variablen zur�ckgegeben.                       #
          * #                                                                         #
          * # Die Funktion arbeitet nur f�r deutsche Banken, da f�r andere keine      #
          * # Infos vorliegen.                                                        #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion iban2bic(String iban) +���4 */
      static String iban2bic(String iban)
      {
         Int32 rv;
         IntPtr blz_p,kto_p;
         String bic;

         blz_p=kc_alloc(10,out rv);
         kto_p=kc_alloc(16,out rv);
         bic=Marshal.PtrToStringAnsi(iban2bic_i(iban,out rv,blz_p,kto_p));
         kc_free(blz_p);
         kc_free(kto_p);
         return bic;
      }
         /* Funktion iban2bic(String iban,out Int32 retval) +���4 */
      static String iban2bic(String iban,out Int32 retval)
      {
         Int32 rv;
         IntPtr blz_p,kto_p;
         String bic;

         blz_p=kc_alloc(10,out rv);
         kto_p=kc_alloc(16,out rv);
         bic=Marshal.PtrToStringAnsi(iban2bic_i(iban,out retval,blz_p,kto_p));
         kc_free(blz_p);
         kc_free(kto_p);
         return bic;
      }
         /* Funktion iban2bic(String iban,out String blz, out String kto) +���4 */
      static String iban2bic(String iban,out String blz, out String kto)
      {
         Int32 rv;
         IntPtr blz_p,kto_p;
         String bic;

         blz_p=kc_alloc(10,out rv);
         kto_p=kc_alloc(16,out rv);
         bic=Marshal.PtrToStringAnsi(iban2bic_i(iban,out rv,blz_p,kto_p));
         blz=Marshal.PtrToStringAnsi(blz_p);
         kto=Marshal.PtrToStringAnsi(kto_p);
         kc_free(blz_p);
         kc_free(kto_p);
         return bic;
      }
         /* Funktion iban2bic(String iban,out String blz, out String kto,out Int32 retval) +���4 */
      static String iban2bic(String iban,out String blz, out String kto,out Int32 retval)
      {
         Int32 rv;
         IntPtr blz_p,kto_p;
         String bic;

         blz_p=kc_alloc(10,out rv);
         kto_p=kc_alloc(16,out rv);
         bic=Marshal.PtrToStringAnsi(iban2bic_i(iban,out retval,blz_p,kto_p));
         blz=Marshal.PtrToStringAnsi(blz_p);
         kto=Marshal.PtrToStringAnsi(kto_p);
         kc_free(blz_p);
         kc_free(kto_p);
         return bic;
      }
#endregion

         /* Funktion iban_gen() +���3 */
#region iban_gen()
         /* Funktion iban_gen(String blz, String kto) +���4 */
      static String iban_gen(String blz, String kto)
      {
         Int32 retval;
         IntPtr iban_p,bic_p;
         String iban;

         iban_p=iban_gen_i(blz,kto,out bic_p,out retval);
         iban=Marshal.PtrToStringAnsi(iban_p);
         kc_free(iban_p);
         return iban;
      }
         /* Funktion iban_gen(String blz, String kto,out Int32 retval) +���4 */
      static String iban_gen(String blz, String kto, out Int32 retval)
      {
         IntPtr iban_p,bic_p;
         String iban;

         iban_p=iban_gen_i(blz,kto,out bic_p,out retval);
         iban=Marshal.PtrToStringAnsi(iban_p);
         kc_free(iban_p);
         return iban;
      }
         /* Funktion iban_gen(String blz, String kto,out String bic) +���4 */
      static String iban_gen(String blz, String kto,out String bic)
      {
         Int32 retval;
         IntPtr iban_p,bic_p;
         String iban;

         iban_p=iban_gen_i(blz,kto,out bic_p,out retval);
         iban=Marshal.PtrToStringAnsi(iban_p);
         bic=Marshal.PtrToStringAnsi(bic_p);
         kc_free(iban_p);
         return iban;
      }
         /* Funktion iban_gen(String blz, String kto,out String bic,out Int32 retval) +���4 */
      static String iban_gen(String blz, String kto,out String bic,out Int32 retval)
      {
         IntPtr iban_p,bic_p;
         String iban;

         iban_p=iban_gen_i(blz,kto,out bic_p,out retval);
         iban=Marshal.PtrToStringAnsi(iban_p);
         bic=Marshal.PtrToStringAnsi(bic_p);
         kc_free(iban_p);
         return iban;
      }
#endregion

         /* Funktion ci_check() +���3 */
#region ci_check()

         /* ###########################################################################
          * # Die Funktion ci_check testet die Pr�fsumme eines Creditor Identifiers   #
          * # (Gl�ubiger-Identifikationsnummer)                                       #
          * #                                                                         #
          * # Copyright (C) 2013 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion ci_check(String ci) +���4 */
      static Int32 ci_check(String ci)
      {
         return ci_check_i(ci);
      }
#endregion

         /* Funktion iban_check() +���3 */
#region iban_check()

         /* ###########################################################################
          * # Die Funktion iban_check pr�ft, ob die Pr�fsumme des IBAN ok ist und     #
          * # testet au�erdem noch die BLZ/Konto Kombination. F�r den Test des Kontos #
          * # wird keine Initialisierung gemacht; diese mu� vorher erfolgen. Der      #
          * # R�ckgabewert ist das Ergebnis der IBAN-Pr�fung; in der (optionalen)     #
          * # Variablen retval wird das Ergebnis der Kontopr�fung (nur f�r deutsche   #
          * # Konten m�glich) zur�ckgegeben.                                          #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion iban_check(String iban) +���4 */
      static Int32 iban_check(String iban)
      {
         Int32 retval;

         return iban_check_i(iban,out retval);
      }
         /* Funktion iban_check(String iban, out Int32 retval) +���4 */
      static Int32 iban_check(String iban, out Int32 retval)
      {
         return iban_check_i(iban,out retval);
      }
#endregion

         /* Funktion ipi_gen() +���3 c*/
#region ipi_gen()

         /* ###########################################################################
          * # Die Funktion ipi_gen generiert einen Strukturierten Verwendungszweck    #
          * # f�r eine IPI (International Payment Instruction). Der Zweck darf nur    #
          * # Buchstaben und Zahlen enthalten; Buchstaben werden dabei in Gro�buch-   #
          * # staben umgewandelt. Andere Zeichen sind hier nicht zul�ssig. Der        #
          * # Verwendungszweck wird links mit Nullen bis auf 18 Byte aufgef�llt, dann #
          * # die Pr�fsumme berechnet und eingesetzt. Optional wird auch eine         #
          * # Papierform (mit einem Leerzeichen nach jeweils 5 Zeichen) sowie ein     #
          * # Statuscode zur�ckgegeben.                                               #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion ipi_gen(String zweck) +���4 */
      static String ipi_gen(String zweck)
      {
         Int32 retval;
         IntPtr papier_p,ipi_p;
         String ipi;

         ipi_p=kc_alloc(24,out retval);
         papier_p=kc_alloc(28,out retval);
         retval=ipi_gen_i(zweck,out ipi_p, out papier_p);
         ipi=Marshal.PtrToStringAnsi(ipi_p);
         kc_free(papier_p);
         kc_free(ipi_p);
         return ipi;
      }
         /* Funktion ipi_gen(String zweck, out Int32 retval) +���4 */
      static String ipi_gen(String zweck, out Int32 retval)
      {
         IntPtr papier_p,ipi_p;
         String ipi;

         ipi_p=kc_alloc(24,out retval);
         papier_p=kc_alloc(28,out retval);
         retval=ipi_gen_i(zweck,out ipi_p, out papier_p);
         ipi=Marshal.PtrToStringAnsi(ipi_p);
         kc_free(papier_p);
         kc_free(ipi_p);
         return ipi;
      }
         /* Funktion ipi_gen(String zweck, out String papier) +���4 */
      static String ipi_gen(String zweck, out String papier)
      {
         Int32 retval;
         IntPtr papier_p,ipi_p;
         String ipi;

         ipi_p=kc_alloc(24,out retval);
         papier_p=kc_alloc(28,out retval);
         retval=ipi_gen_i(zweck,out ipi_p, out papier_p);
         ipi=Marshal.PtrToStringAnsi(ipi_p);
         papier=Marshal.PtrToStringAnsi(papier_p);
         kc_free(papier_p);
         kc_free(ipi_p);
         return ipi;
      }
         /* Funktion ipi_gen(String zweck, out String papier, out Int32 retval) +���4 */
      static String ipi_gen(String zweck, out String papier,out Int32 retval)
      {
         IntPtr papier_p,ipi_p;
         String ipi;

         ipi_p=kc_alloc(24,out retval);
         papier_p=kc_alloc(28,out retval);
         retval=ipi_gen_i(zweck,out ipi_p, out papier_p);
         ipi=Marshal.PtrToStringAnsi(ipi_p);
         papier=Marshal.PtrToStringAnsi(papier_p);
         kc_free(papier_p);
         kc_free(ipi_p);
         return ipi;
      }
#endregion

         /* Funktion ipi_check() +���3 */
#region ipi_check()

         /* ###########################################################################
          * # Die Funktion ipi_check testet einen Strukturierten Verwendungszweck     #
          * # f�r eine IPI (International Payment Instruction). Der Zweck darf nur    #
          * # Buchstaben und Zahlen enthalten und mu� genau 20 Byte lang sein, wobei  #
          * # eingestreute Blanks oder Tabs ignoriert werden.                         #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion ipi_check(String ipi) +���4 */
         /* Die Funktion kann direkt aus der DLL aufgerufen werden, ohne Wrapper */
#endregion
#endregion

/* C#-Definitionen: Suchfunktionen +���2 */
#region Suchfunktionen

         /* Die Suchfunktionen der C-Bibliothek stellen ein Low-Level Interface
          * zur Verf�gung, das durch C#.net nur schlecht unterst�tzt wird. Die
          * Funktionen sind so implementiert, da� zun�chst ein Array mit den
          * Indizes der Bankleitzahlen in der gew�nschten Suchordnung erstellt
          * (bzw. eingelesen) wird; f�r eine konkrete Suche wird dann ein
          * Pointer auf den ersten Index, der die Suchkriterien erf�llt sowie
          * die Anzahl der Banken, die das Kriterium erf�llen, zur�ckgegeben.
          * Auch f�r die Zweigstellen wird nur ein Pointer auf ein Array
          * zur�ckgegeben, das f�r jeden Index die Nummer der jeweiligen
          * Zweigstelle enth�lt.
          *
          * Da C#.net einen wahlfreien Zugriff in IntPtr-Feldern (mit einem
          * beliebigem Startindex, normalerweise ungleich 0) - soweit ich bis
          * jetzt gesehen habe - nicht unterst�tzt, wurde eine zus�tzliche
          * Funktion kto_check_idx2blz() geschrieben, das zu einem gegebenen
          * Index BLZ und Zweigstelle zur�ckliefert. Die Funktion ist erst ab
          * Version 4.0 verf�gbar; f�r fr�here Versionen der DLL sind die
          * Suchfunktionen daher nicht verwendbar.
          *
          * Die C-Funktionen geben u.a. noch einen (oder mehrere) char-Pointer
          * zur�ck, in denen die gefundenen Werte zur�ckgegeben werden. Diese
          * Pointer werden hier nur als Dummy-Variablen (mit dem Typ IntPtr)
          * �bergeben, aber nicht ausgewertet.
          */

         /* Funktion bank_suche_bic() +���3 */
#region bank_suche_bic()

         /* ###########################################################################
          * # bank_suche_bic(): Banken mit gegebenem BIC suchen.                      #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_bic(String bic) +���4 */
      static Int32[] bank_suche_bic(String bic)
      {
         Int32 retval;
         return bank_suche_bic(bic,out retval);
      }
         /* Funktion bank_suche_bic(String bic, out Int32 retval) +���4 */
      static Int32[] bank_suche_bic(String bic, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_bic(bic, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_bic(String bic, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_bic(String bic, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_bic(bic,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_bic(String bic, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_bic(String bic, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_bic(bic, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_namen() +���3 */
#region bank_suche_namen()

         /* ###########################################################################
          * # bank_suche_namen: Banken mit gegebenem Langnamen suchen.                #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_namen(String namen) +���4 */
      static Int32[] bank_suche_namen(String namen)
      {
         Int32 retval;
         return bank_suche_namen(namen,out retval);
      }
         /* Funktion bank_suche_namen(String namen, out Int32 retval) +���4 */
      static Int32[] bank_suche_namen(String namen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_namen(namen, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_namen(String namen, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_namen(String namen, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_namen(namen,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_namen(String namen, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_namen(String namen, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_namen(namen, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_namen_kurz() +���3 */
#region bank_suche_namen_kurz()

         /* ###########################################################################
          * # bank_suche_namen_kurz: Banken gegebenem Kurznamen suchen.               #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_namen_kurz(String namen_kurz) +���4 */
      static Int32[] bank_suche_namen_kurz(String namen_kurz)
      {
         Int32 retval;
         return bank_suche_namen_kurz(namen_kurz,out retval);
      }
         /* Funktion bank_suche_namen_kurz(String namen_kurz, out Int32 retval) +���4 */
      static Int32[] bank_suche_namen_kurz(String namen_kurz, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_namen_kurz(namen_kurz, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_namen_kurz(String namen_kurz, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_namen_kurz(String namen_kurz, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_namen_kurz(namen_kurz,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_namen_kurz(String namen_kurz, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_namen_kurz(String namen_kurz, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_namen_kurz(namen_kurz, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_ort() +���3 */
#region bank_suche_ort()

         /* ###########################################################################
          * # bank_suche_ort: Banken in einem gegebenen Ort suchen.                   #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_ort(String ort) +���4 */
      static Int32[] bank_suche_ort(String ort)
      {
         Int32 retval;
         return bank_suche_ort(ort,out retval);
      }
         /* Funktion bank_suche_ort(String ort, out Int32 retval) +���4 */
      static Int32[] bank_suche_ort(String ort, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_ort(ort, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_ort(String ort, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_ort(String ort, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_ort(ort,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_ort(String ort, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_ort(String ort, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_ort(ort, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_plz() +���3 */
#region bank_suche_plz()

         /* ###########################################################################
          * # bank_suche_plz: Banken mit vorgegebener PLZ oder PLZ zwischen plz1 und  #
          * # plz2 suchen.                                                            #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_plz(Int32 plz) +���4 */
      static Int32[] bank_suche_plz(Int32 plz)
      {
         Int32 retval;
         return bank_suche_plz(plz,plz,out retval);
      }
         /* Funktion bank_suche_plz(Int32 plz1, Int32 plz2) +���4 */
      static Int32[] bank_suche_plz(Int32 plz1, Int32 plz2)
      {
         Int32 retval;
         return bank_suche_plz(plz1,plz2,out retval);
      }
         /* Funktion bank_suche_plz(Int32 plz1, Int32 plz2, out Int32 retval) +���4 */
      static Int32[] bank_suche_plz(Int32 plz1, Int32 plz2, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_plz(plz1, plz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_plz(Int32 plz1, Int32 plz2, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_plz(Int32 plz1, Int32 plz2, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_plz(plz1, plz2,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_plz(Int32 plz1, Int32 plz2, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_plz(Int32 plz1, Int32 plz2, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_plz(plz1, plz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_blz() +���3 */
#region bank_suche_blz()

         /* ###########################################################################
          * # bank_suche_blz: Banken mit vorgegebener BLZ oder BLZ zwischen blz1 und  #
          * # blz2 suchen.                                                            #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_blz(Int32 blz) +���4 */
      static Int32[] bank_suche_blz(Int32 blz)
      {
         Int32 retval;
         return bank_suche_blz(blz,blz,out retval);
      }
         /* Funktion bank_suche_blz(Int32 blz1, Int32 blz2) +���4 */
      static Int32[] bank_suche_blz(Int32 blz1, Int32 blz2)
      {
         Int32 retval;
         return bank_suche_blz(blz1,blz2,out retval);
      }
         /* Funktion bank_suche_blz(Int32 blz1, Int32 blz2, out Int32 retval) +���4 */
      static Int32[] bank_suche_blz(Int32 blz1, Int32 blz2, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_blz(blz1, blz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_blz(Int32 blz1, Int32 blz2, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_blz(Int32 blz1, Int32 blz2, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_blz(blz1, blz2,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_blz(Int32 blz1, Int32 blz2, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_blz(Int32 blz1, Int32 blz2, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_blz(blz1, blz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_pz() +���3 */
#region bank_suche_pz()

         /* ###########################################################################
          * # bank_suche_pz: Banken mit vorgegebenem Pr�fzifferverfahren pz oder      #
          * # Pr�fzifferverfahren zwischen pz1 und pz2 suchen.                        #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_pz(Int32 pz) +���4 */
      static Int32[] bank_suche_pz(Int32 pz)
      {
         Int32 retval;
         return bank_suche_pz(pz,pz,out retval);
      }
         /* Funktion bank_suche_pz(Int32 pz1, Int32 pz2) +���4 */
      static Int32[] bank_suche_pz(Int32 pz1, Int32 pz2)
      {
         Int32 retval;
         return bank_suche_pz(pz1,pz2,out retval);
      }
         /* Funktion bank_suche_pz(Int32 pz1, Int32 pz2, out Int32 retval) +���4 */
      static Int32[] bank_suche_pz(Int32 pz1, Int32 pz2, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_pz(pz1, pz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_pz(Int32 pz1, Int32 pz2, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_pz(Int32 pz1, Int32 pz2, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_pz(pz1, pz2,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_pz(Int32 pz1, Int32 pz2, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_pz(Int32 pz1, Int32 pz2, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_pz(pz1, pz2, out anzahl, out start_idx, out zs, out base_name, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_volltext() +���3 */
#region bank_suche_volltext()

         /* ###########################################################################
          * # bank_suche_volltext: Volltextsuche in Langnamen, Kurznamen und Ort      #
          * #                                                                         #
          * # Copyright (C) 2012 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_volltext(String such_wort) +���4 */
      static Int32[] bank_suche_volltext(String such_wort)
      {
         Int32 retval;
         return bank_suche_volltext(such_wort,out retval);
      }
         /* Funktion bank_suche_volltext(String such_wort, out Int32 retval) +���4 */
      static Int32[] bank_suche_volltext(String such_wort, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw, base_name_idx, zweigstellen_anzahl;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_volltext(such_wort, out anzahl, out base_name_idx, out base_name, out zweigstellen_anzahl, out start_idx, out zs, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
         return blz_a;
      }
         /* Funktion bank_suche_volltext(String such_wort, out int[] zweigstellen) +���4 */
      static Int32[] bank_suche_volltext(String such_wort, out int[] zweigstellen)
      {
         Int32 retval;
         return bank_suche_volltext(such_wort,out zweigstellen,out retval);
      }
         /* Funktion bank_suche_volltext(String such_wort, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_volltext(String such_wort, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl, rv, i, zw, base_name_idx, zweigstellen_anzahl;
         IntPtr start_idx, zs, base_name, blz_base;

         retval = lut_suche_volltext(such_wort, out anzahl, out base_name_idx, out base_name, out zweigstellen_anzahl, out start_idx, out zs, out blz_base);
         int[] idx_a = new int[anzahl];
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(start_idx, idx_a, 0, anzahl);
         for (i = 0; i < anzahl; i++)
         {
            blz_a[i] = kto_check_idx2blz(idx_a[i], out zw, out rv);
            zweigstellen[i] = zw;
         }
         return blz_a;
      }
#endregion

         /* Funktion bank_suche_multiple() +���3 */
#region bank_suche_multiple()

         /* ###########################################################################
          * # bank_suche_multiple: Suche nach mehreren Kriterien                      #
          * #                                                                         #
          * # Copyright (C) 2012 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_suche_multiple(String such_str) +���4 */
      static Int32[] bank_suche_multiple(String such_str)
      {
         Int32 retval;
         return bank_suche_multiple(such_str,0,"",out retval);
      }
         /* Funktion bank_suche_multiple(String such_str,Int32 uniq, String such_cmd) +���4 */
      static Int32[] bank_suche_multiple(String such_str,Int32 uniq, String such_cmd)
      {
         Int32 retval;
         return bank_suche_multiple(such_str,uniq,such_cmd,out retval);
      }
         /* Funktion bank_suche_multiple(String such_str,Int32 uniq, String such_cmd, out Int32 retval) +���4 */
      static Int32[] bank_suche_multiple(String such_str,Int32 uniq, String such_cmd, out Int32 retval)
      {
         Int32 anzahl;
         IntPtr zs, blz_base;

         retval = lut_suche_multiple(such_str, uniq, such_cmd, out anzahl, out zs, out blz_base);
         int[] blz_a = new int[anzahl];
         Marshal.Copy(blz_a, 0, blz_base, anzahl);
         kc_free(blz_base);
         kc_free(zs);
         return blz_a;
      }
         /* Funktion bank_suche_multiple(String such_str, Int32 uniq, String such_cmd, out int[] zweigstellen, out Int32 retval) +���4 */
      static Int32[] bank_suche_multiple(String such_str, Int32 uniq, String such_cmd, out int[] zweigstellen, out Int32 retval)
      {
         Int32 anzahl;
         IntPtr zs, blz_base;

         retval = lut_suche_multiple(such_str, uniq, such_cmd, out anzahl, out zs, out blz_base);
         int[] blz_a = new int[anzahl];
         zweigstellen = new int[anzahl];
         Marshal.Copy(blz_a, 0, blz_base, anzahl);
         Marshal.Copy(zweigstellen, 0, zs, anzahl);
         kc_free(blz_base);
         kc_free(zs);
         return blz_a;
      }
#endregion

#endregion

/* C#-Definitionen: Funktionen f�r die LUT-datei +���2 */
#region Funktionen f�r die LUT-datei
         /* Funktion bank_blz() +���3 */
#region Funktion bank_blz()

         /* ###########################################################################
          * # bank_blz(): Test ob eine BLZ existiert                                  #
          * # Diese Funktion testet, ob eine BLZ (und Zweigstelle, falls gew�nscht)   #
          * # existiert und g�ltig ist.                                               #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_blz(String blz) +���4 */
      static Int32 bank_blz(String blz)
      {
         return lut_blz(blz,0);
      }
         /* Funktion bank_blz(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_blz(String blz, Int32 zweigstelle)
      {
         return lut_blz(blz, zweigstelle);
      }
#endregion

         /* Funktion lut_info() +���3 */
#region Funktion lut_info()

         /* Funktion lut_info() */
         /* ###########################################################################
          * # Die Funktion lut_info() extrahiert die beiden Infoblocks aus einer      #
          * # LUT-Datei und vergleicht das G�ltigkeitsdatum mit dem aktuellen Datum.  #
          * # Falls eine LUT-Datei keinen Infoblock oder kein G�ltigkeitsdatum        #
          * # enth�lt, wird (in den Variablen valid1 bzw. valid2) ein entsprechender  #
          * # Fehlercode zur�ckgegeben.                                               #
          * #                                                                         #
          * # Falls als Dateiname NULL oder ein Leerstring �bergeben wird, wird die   #
          * # G�ltigkeit des aktuell geladenen Datensatzes bestimmt, und (optional)   #
          * # mit dem zugeh�rigen Infoblock zur�ckgegeben. In diesem Fall wird info2  #
          * # auf "" und valid2 auf LUT2_BLOCK_NOT_IN_FILE gesetzt.                   #
          * #                                                                         #
          * # Parameter:                                                              #
          * #    lut_name: Name der LUT-Datei oder NULL/Leerstring                    #
          * #    info1:    R�ckgabestring mit dem prim�ren Infoblock                  #
          * #    info2:    R�ckgabestring mit dem sekund�ren Infoblock                #
          * #    valid1:   Statusvariable f�r den prim�ren Datensatz                  #
          * #    valid2:   Statusvariable f�r den sekund�ren Datensatz                #
          * #                                                                         #
          * # R�ckgabewerte:                                                          #
          * #    OK:                     ok, weiteres in valid1 und valid2            #
          * #    LUT2_NOT_INITIALIZED:   die library wurde noch nicht initialisiert   #
          * #                                                                         #
          * # Werte f�r valid1 und valid2:                                            #
          * #    LUT2_VALID:             Der Datenblock ist aktuell g�ltig            #
          * #    LUT2_NO_LONGER_VALID:   Der Datenblock ist nicht mehr g�ltig         #
          * #    LUT2_NOT_YET_VALID:     Der Datenblock ist noch nicht g�ltig         #
          * #    LUT2_NO_VALID_DATE:     Der Datenblock enth�lt kein G�ltigkeitsdatum #
          * #    LUT2_BLOCK_NOT_IN_FILE: Die LUT-Datei enth�lt den Infoblock nicht    #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion lut_info(out String info,out Int32 valid) +���4 */
      static Int32 lut_info(out String info,out Int32 valid)
      {
         Int32 retval,valid2;
         IntPtr info1_p,info2_p;

         retval=lut_info_i("",out info1_p,out info2_p,out valid,out valid2);
         info=Marshal.PtrToStringAnsi(info1_p);
         kc_free(info1_p);
         kc_free(info2_p);
         return retval;
      }
         /* Funktion lut_info(String lutfile,Int32 set,out String info,out Int32 valid) +���4 */
      static Int32 lut_info(String lutfile,Int32 set,out String info,out Int32 valid)
      {
         Int32 retval,valid1,valid2;
         IntPtr info1_p,info2_p;

         retval=lut_info_i(lutfile,out info1_p,out info2_p,out valid1,out valid2);
         if(set==1){
            info=Marshal.PtrToStringAnsi(info1_p);
            valid=valid1;
         }
         else if(set==2){
            info=Marshal.PtrToStringAnsi(info2_p);
            valid=valid2;
         }
         else{
            info="";
            valid=0;
         }
         kc_free(info1_p);
         kc_free(info2_p);
         return retval;
      }
         /* Funktion lut_info(String lutfile,out String info1,out Int32 valid1,out String info2,out Int32 valid2) +���4 */
      static Int32 lut_info(String lutfile,out String info1,out Int32 valid1,out String info2,out Int32 valid2)
      {
         Int32 retval;
         IntPtr info1_p,info2_p;

         retval=lut_info_i(lutfile,out info1_p,out info2_p,out valid1,out valid2);
         info1=Marshal.PtrToStringAnsi(info1_p);
         info2=Marshal.PtrToStringAnsi(info2_p);
         kc_free(info1_p);
         kc_free(info2_p);
         return retval;
      }
#endregion

         /* Funktion generate_lut() +���3 */
#region Funktion generate_lut()

         /* ###########################################################################
          * # generate_lut(): LUT-Datei generieren.                                   #
          * #                                                                         #
          * # Diese Funktion generiert aus der Textdatei der Deutschen Bundesbank     #
          * # eine LUT-Datei die f�r die konto_check Bibliothek ben�tigt wird.        #
          * # Die Felder der Bundesbankdatei werden dabei in einzelnen Blocks in der  #
          * # LUT-Datei gespeichert, die unabh�ngig voneinander eingelesen werden     #
          * # k�nnen und in einem (normalerweise mittels zlib) komprimierten Format   #
          * # gespeichert werden. In einer LUT-Datei k�nnen zwei Datens�tze (d.h.     #
          * # zwei Bundesbankdateien) mit unterschiedlichem G�ltigkeitsdatum          #
          * # gespeichert werden. Die Entscheidung welcher Datensatz aktuell g�ltig   #
          * # ist wird bei der Initialisierung anhand des Systemdatums gef�llt.       #
          * # Es ist ferner m�glich, nur die Daten der Hauptstellen in die LUT-Datei  #
          * # aufzunehmen; die Datei wird dadurch nat�rlich wesentlich kleiner.       #
          * #                                                                         #
          * # Folgende Parameter werden unterst�tzt:                                  #
          * #                                                                         #
          * # inputname:      Name der Bundesbankdatei (Textversion)                  #
          * #                                                                         #
          * # outputname:     Name zu generierenden LUT-Datei                         #
          * #                                                                         #
          * # user_info:      Kommentarfeld in der LUT-Datei                          #
          * #                                                                         #
          * # gueltigkeit:    G�ltigkeit des Datensatzes im Format JJJJMMDD-JJJJMMDD  #
          * #                                                                         #
          * # iban_blacklist: Name der Datei mit den Instituten, die einer            #
          * #                 Selbstberechnung der IBAN nicht zugestimmt haben.       #
          * #                 N�here Infos und Weblinks zu dieser Datei gibt es bei   #
          * #                 der Funktion lut_keine_iban_berechnung() (s.u.).        #
          * #                                                                         #
          * # felder:         Integer (0...9), welche Blocks in die LUT-Datei         #
          * #                 aufgenommen werden sollen. Eine Liste der Blocks findet #
          * #                 sich im Anhang der Datei 00liesmich.pdf.                #
          * #                                                                         #
          * # filialen:       Flag (0 oder 1), ob die Daten der Filialen aufgenommen  #
          * #                 werden sollen.                                          #
          * #                                                                         #
          * # slots:          Anzahl Slots im Inhaltsverzeichnis der LUT-Datei. Diese #
          * #                 Zahl kann nachtr�glich nicht mehr ge�ndert werden; sie  #
          * #                 gibt die maximale Anzahl Blocks an, die in der Datei    #
          * #                 enthalten sein k�nnen. Der Minimalwert f�r diesen       #
          * #                 Parameter ist in konto_check.h mit 40 festgelegt.       #
          * #                                                                         #
          * #                                                                         #
          * # set:            (Integer 0, 1, 2 oder 10, 11, 12). Angabe welcher       #
          * #                 Datensatz geschrieben werden soll. Bei 0 wird die Datei #
          * #                 neu angelegt und der Datensatz 1 geschrieben; bei 1     #
          * #                 oder 2 wird der entsprechende Datensatz an die          #
          * #                 LUT-Datei angeh�ngt. Falls in der Datei schon Blocks    #
          * #                 mit derselben Blocknummer enthalten sind, werden sie    #
          * #                 durch die neuen Blocks ersetzt.                         #
          * #                                                                         #
          * #                 Die Werte 10, 11 und 12 entsprechen den F�llen 0, 1 und #
          * #                 2; nur wird in dem Fall kein Indexblock f�r die Suche   #
          * #                 nach den verschiedenen Werten geschrieben; der Index    #
          * #                 mu� in diesem Fall jeweils beim ersten Aufruf einer     #
          * #                 Suchfunktion generiert werden.                          #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion generate_lut(String inputname,String outputname) +���4 */
      static Int32 generate_lut(String inputname,String outputname)
      {
         return generate_lut2_p(inputname,outputname,"","",0,0,0,0,0);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info)
      {
         return generate_lut2_p(inputname,outputname,user_info,"",0,0,0,0,0);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit)
      {
         return generate_lut2_p(inputname,outputname,user_info,gueltigkeit,0,0,0,0,0);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,String iban_blacklist) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,String iban_blacklist)
      {
         Int32 retval;

         if((retval=generate_lut2_p(inputname,outputname,user_info,gueltigkeit,0,0,0,0,0))<=0)return retval;
         lut_keine_iban_berechnung_i(iban_blacklist,outputname,0);
         return retval;
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,Int32 felder) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,Int32 felder)
      {
         return generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,0,0,0,0);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,String iban_blacklist,Int32 felder) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,String iban_blacklist,Int32 felder)
      {
         Int32 retval;

         if((retval=generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,0,0,0,0))<=0)return retval;
         lut_keine_iban_berechnung_i(iban_blacklist,outputname,0);
         return retval;
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,Int32 felder,Int32 filialen) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,Int32 felder,Int32 filialen)
      {
         return generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,0,0,0);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen)
      {
         Int32 retval;

         if((retval=generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,0,0,0))<=0)return retval;
         lut_keine_iban_berechnung_i(iban_blacklist,outputname,0);
         return retval;
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,Int32 felder,Int32 filialen,Int32 set) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,Int32 felder,Int32 filialen,Int32 set)
      {
         return generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,0,0,set);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen,Int32 set) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen,Int32 set)
      {
         Int32 retval;

         if((retval=generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,0,0,set))<=0)return retval;
         lut_keine_iban_berechnung_i(iban_blacklist,outputname,0);
         return retval;
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,Int32 felder,Int32 filialen,Int32 slots,Int32 set) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,Int32 felder,Int32 filialen,Int32 slots,Int32 set)
      {
         return generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,slots,0,set);
      }
         /* Funktion generate_lut(String inputname,String outputname,String user_info, String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen,Int32 slots,Int32 set) +���4 */
      static Int32 generate_lut(String inputname,String outputname,String user_info,
               String gueltigkeit,String iban_blacklist,Int32 felder,Int32 filialen,Int32 slots,Int32 set)
      {
         Int32 retval;

         if((retval=generate_lut2_p(inputname,outputname,user_info,gueltigkeit,felder,filialen,slots,0,set))<=0)return retval;
         lut_keine_iban_berechnung_i(iban_blacklist,outputname,0);
         return retval;
      }
#endregion

         /* Funktion lut_keine_iban_berechnung() +���3 */
#region Funktion lut_keine_iban_berechnung()

         /* ############################################################################
          * # Die Funktion lut_keine_iban_berechnung() konvertiert die Liste der       #  
          * # Banken, die einer IBAN-Berechnung nicht zugestimmt haben in das interne  #
          * # Format f�r konto_check. Als Eingabedatei wird die Datei CONFIG.INI des   #
          * # SEPA Account Converters der Sparkassen benutzt, die Ausgabe wird direkt  #
          * # als Block in die LUT-Datei geschrieben. Der Block wird automatisch beim  #
          * # Initialisieren eingelesen und von der Funktion iban_gen() ausgewertet.   #
          * #                                                                          #
          * # Hier ein Auszug aus der Anleitung des SEPA Account Converters:           #
          * #                                                                          #
          * # Der SEPA Account Converter ist so eingestellt, dass nur                  #
          * # Kontoverbindungen in IBAN und BIC umgerechnet werden, bei denen das      #
          * # ausgebende Kreditinstitut der Umrechnung zugestimmt hat.                 #
          * # Kreditinstitute, welche einer Umrechnung nicht zugestimmt haben und      #
          * # welche zum Teil spezielle, dem SEPA Account Converter nicht bekannte     #
          * # Umrechnungsmethoden verwenden, sind in der Datei "CONFIG.INI"            #
          * # hinterlegt. Durch L�schen der Datei "CONFIG.INI" aus dem                 #
          * # Programmverzeichnis haben Sie die M�glichkeit, eine Umrechnung f�r alle  #
          * # Konten durchzuf�hren. Bitte beachten Sie dabei, dass die so erhaltenen   #
          * # IBAN und BIC fehlerhaft sein k�nnen und deshalb mit ihren Kunden zu      #
          * # �berpr�fen sind.                                                         #
          * ############################################################################
          */ 

         /* Weblinks:
          * https://www.sparkasse-rhein-neckar-nord.de/pdf/content/sepa/kurzanleitung.pdf
          * https://www.sparkasse-rhein-neckar-nord.de/firmenkunden/internationales_geschaeft/sepa/vorteile/index.php
          * https://www.sparkasse-rhein-neckar-nord.de/firmenkunden/internationales_geschaeft/sepa/vorteile/sepa_account_converter.msi
          * http://www.sfirm.de/update/prgupd.htm
          */

         /* Funktion lut_keine_iban_berechnung(String iban_blacklist,String lutfile) +���4 */
      static Int32 lut_keine_iban_berechnung(String iban_blacklist,String lutfile)
      {
         return lut_keine_iban_berechnung_i(iban_blacklist,lutfile,0);
      }
         /* Funktion lut_keine_iban_berechnung(String iban_blacklist,String lutfile,Int32 set) +���4 */
      static Int32 lut_keine_iban_berechnung(String iban_blacklist,String lutfile,Int32 set)
      {
         return lut_keine_iban_berechnung_i(iban_blacklist,lutfile,set);
      }
#endregion

         /* Funktion lut_dir_dump_str() +���3 */
#region Funktion lut_dir_dump_str()

         /* ###########################################################################
          * # Die Funktion lut_dir_dump_str liest eine LUT-Datei und gibt die Infos   #
          * # zu den enthaltenen Blocks im Ausgabestring zur�ck. Au�erdem wird noch   #
          * # die Gesamtgr��e der Daten (sowohl komprimiert als auch unkomprimiert)   #
          * # ausgegeben.                                                             #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion lut_dir_dump_str(String lutfile) +���4 */
      static String lut_dir_dump_str(String lutfile)
      {
         Int32 retval;
         IntPtr dptr;
         String lut_dir;

         retval=lut_dir_dump_str_i(lutfile,out dptr);
         lut_dir=Marshal.PtrToStringAnsi(dptr);
         kc_free(dptr);
         return lut_dir;
      }
         /* Funktion lut_dir_dump_str(String lutfile, out Int32 retval) +���4 */
      static String lut_dir_dump_str(String lutfile,out Int32 retval)
      {
         IntPtr dptr;
         String lut_dir;

         retval=lut_dir_dump_str_i(lutfile,out dptr);
         lut_dir=Marshal.PtrToStringAnsi(dptr);
         kc_free(dptr);
         return lut_dir;
      }
#endregion

         /* Funktion bank_filialen() +���3 */
#region Funktion bank_filialen()

         /* ###########################################################################
          * # bank_filialen(): Anzahl der Filialen zu einer gegebenen Bankleitzahl    #
          * # bestimmen.                                                              #
          * #                                                                         #
          * # Copyright (C) 2007 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_filialen(String blz) +���4 */
      static Int32 bank_filialen(String blz)
      {
         Int32 retval;

         return lut_filialen(blz,out retval);
      }
         /* Funktion bank_filialen(String blz, out Int32 retval) +���4 */
      static Int32 bank_filialen(String blz, out Int32 retval)
      {
         return lut_filialen(blz, out retval);
      }
#endregion

         /* Die folgenden Funktionen haben jeweils drei Parameter: BLZ, Filiale
          * und retval. Die BLZ ist notwendig, Filiale und retval sind
          * optional. Falls die Filiale nicht angegeben wird wird 0 angenommen
          * (Hauptstelle). In der Variablen retval wird ein Statuscode zum
          * Funktionsaufruf zur�ckgegeben.
          */
         /* Funktion bank_name() +���3 */
#region Funktion bank_name()

         /* ###########################################################################
          * # bank_name(): Banknamen (lange Form) bestimmen                           #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_name(String blz) +���4 */
      static String bank_name(String blz)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_name(blz, 0, out retval));
      }
         /* Funktion bank_name(String blz, out Int32 retval) +���4 */
      static String bank_name(String blz, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_name(blz, 0, out retval));
      }
         /* Funktion bank_name(String blz, Int32 zweigstelle) +���4 */
      static String bank_name(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_name(blz, zweigstelle, out retval));
      }
         /* Funktion bank_name(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static String bank_name(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_name(blz, zweigstelle, out retval));
      }
#endregion

         /* Funktion bank_name_kurz() +���3 */
#region Funktion bank_name_kurz()

         /* ###########################################################################
          * # bank_name_kurz(): Kurzbezeichnung mit Ort einer Bank bestimmen          #
          * #                                                                         #
          * # Kurzbezeichnung und Ort sollen f�r die Empf�ngerangaben auf Rechnungen  #
          * # und Formularen angegeben werden. Hierdurch wird eine eindeutige Zu-     #
          * # ordnung der eingereichten Zahlungsauftr�ge erm�glicht. Auf Grund der    #
          * # Regelungen in den Richtlinien beziehungsweise Zahlungsverkehrs-Abkommen #
          * # der deutschen Kreditwirtschaft ist die L�nge der Angaben f�r die        #
          * # Bezeichnung des Kreditinstituts begrenzt.                               #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_name_kurz(String blz) +���4 */
      static String bank_name_kurz(String blz)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_name_kurz(blz, 0, out retval));
      }
         /* Funktion bank_name_kurz(String blz, out Int32 retval) +���4 */
      static String bank_name_kurz(String blz, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_name_kurz(blz, 0, out retval));
      }
         /* Funktion bank_name_kurz(String blz, Int32 zweigstelle) +���4 */
      static String bank_name_kurz(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_name_kurz(blz, zweigstelle, out retval));
      }
         /* Funktion bank_name_kurz(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static String bank_name_kurz(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_name_kurz(blz, zweigstelle, out retval));
      }
#endregion

         /* Funktion bank_plz() +���3 */
#region Funktion bank_plz()

         /* ###########################################################################
          * # bank_plz(): Postleitzahl bestimmen                                      #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_plz(String blz) +���4 */
      static Int32 bank_plz(String blz)
      {
         Int32 retval;
         return lut_plz(blz, 0, out retval);
      }
         /* Funktion bank_plz(String blz, out Int32 retval) +���4 */
      static Int32 bank_plz(String blz, out Int32 retval)
      {
         return lut_plz(blz, 0, out retval);
      }
         /* Funktion bank_plz(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_plz(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_plz(blz, zweigstelle, out retval);
      }
         /* Funktion bank_plz(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_plz(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_plz(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_ort() +���3 */
#region Funktion bank_ort()

         /* ###########################################################################
          * # bank_ort(): Sitz einer Bank bestimmen                                   #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_ort(String blz) +���4 */
      static String bank_ort(String blz)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_ort(blz, 0, out retval));
      }
         /* Funktion bank_ort(String blz, out Int32 retval) +���4 */
      static String bank_ort(String blz, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_ort(blz, 0, out retval));
      }
         /* Funktion bank_ort(String blz, Int32 zweigstelle) +���4 */
      static String bank_ort(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_ort(blz, zweigstelle, out retval));
      }
         /* Funktion bank_ort(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static String bank_ort(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_ort(blz, zweigstelle, out retval));
      }
#endregion

         /* Funktion bank_pan() +���3 */
#region Funktion bank_pan()

         /* ###########################################################################
          * # bank_pan(): PAN-Nummer bestimmen                                        #
          * #                                                                         #
          * # F�r den internationalen Kartenzahlungsverkehr mittels Bankkunden-       #
          * # karten haben die Spitzenverb�nde des Kreditgewerbes und die Deutsche    #
          * # Bundesbank eine gesonderte Institutsnummerierung festgelegt; danach     #
          * # erh�lt das kartenausgebende Kreditinstitut eine f�nfstellige Instituts- #
          * # nummer f�r PAN (= Primary Account Number). Diese setzt sich zusammen    #
          * # aus der Institutsgruppennummer (grunds�tzlich = vierte Stelle der       #
          * # Bankleitzahl) und einer nachfolgenden vierstelligen, von den einzelnen  #
          * # Institutionen frei gew�hlten Nummer. Abweichend hiervon ist den         #
          * # Mitgliedsinstituten des Bundesverbandes deutscher Banken e.V. sowie     #
          * # den Stellen der Deutschen Bundesbank stets die Institutsgruppennummer   #
          * # 2 zugewiesen worden.                                                    #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_pan(String blz) +���4 */
      static Int32 bank_pan(String blz)
      {
         Int32 retval;
         return lut_pan(blz, 0, out retval);
      }
         /* Funktion bank_pan(String blz, out Int32 retval) +���4 */
      static Int32 bank_pan(String blz, out Int32 retval)
      {
         return lut_pan(blz, 0, out retval);
      }
         /* Funktion bank_pan(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_pan(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_pan(blz, zweigstelle, out retval);
      }
         /* Funktion bank_pan(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_pan(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_pan(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_bic() +���3 */
#region Funktion bank_bic()

         /* ###########################################################################
          * # bank_bic(): BIC (Bank Identifier Code) einer Bank bestimmen.            #
          * #                                                                         #
          * # Der Bank Identifier Code (BIC) besteht aus acht oder elf                #
          * # zusammenh�ngenden Stellen und setzt sich aus den Komponenten BANKCODE   #
          * # (4 Stellen), L�NDERCODE (2 Stellen), ORTSCODE (2 Stellen) sowie ggf.    #
          * # einem FILIALCODE (3 Stellen) zusammen.                                  #
          * #                                                                         #
          * # Jedes Kreditinstitut f�hrt grunds�tzlich einen BIC je Bankleitzahl und  #
          * # teilt diesen der Deutschen Bundesbank mit. Ausnahmen hiervon k�nnen auf #
          * # Antrag f�r Bankleitzahlen zugelassen werden, die im BIC-gest�tzten      #
          * # Zahlungsverkehr (grenz�berschreitender Zahlungsverkehr und inl�ndischer #
          * # Individualzahlungsverkehr) nicht verwendet werden.                      #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_bic(String blz) +���4 */
      static String bank_bic(String blz)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_bic(blz, 0, out retval));
      }
         /* Funktion bank_bic(String blz, out Int32 retval) +���4 */
      static String bank_bic(String blz, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_bic(blz, 0, out retval));
      }
         /* Funktion bank_bic(String blz, Int32 zweigstelle) +���4 */
      static String bank_bic(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return Marshal.PtrToStringAnsi(lut_bic(blz, zweigstelle, out retval));
      }
         /* Funktion bank_bic(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static String bank_bic(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return Marshal.PtrToStringAnsi(lut_bic(blz, zweigstelle, out retval));
      }
#endregion

         /* Funktion bank_nr() +���3 */
#region Funktion bank_nr()

         /* ###########################################################################
          * # bank_nr(): Nummer des Datensatzes in der BLZ-Datei                      #
          * #                                                                         #
          * # Bei jeder Neuanlage eines Datensatzes wird von der Deutschen Bundesbank #
          * # automatisiert eine eindeutige Nummer vergeben. Eine einmal verwendete   #
          * # Nummer wird nicht noch einmal vergeben.                                 #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_nr(String blz) +���4 */
      static Int32 bank_nr(String blz)
      {
         Int32 retval;
         return lut_nr(blz, 0, out retval);
      }
         /* Funktion bank_nr(String blz, out Int32 retval) +���4 */
      static Int32 bank_nr(String blz, out Int32 retval)
      {
         return lut_nr(blz, 0, out retval);
      }
         /* Funktion bank_nr(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_nr(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_nr(blz, zweigstelle, out retval);
      }
         /* Funktion bank_nr(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_nr(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_nr(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_pz() +���3 */
#region Funktion bank_pz()

         /* ###########################################################################
          * # bank_pz(): Pr�fzifferverfahren f�r eine Bankleitzahl. Das Verfahren wird#
          * # numerisch zur�ckgegeben, also z.B. 108 f�r die Methode A8.              #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_pz(String blz) +���4 */
      static Int32 bank_pz(String blz)
      {
         Int32 retval;
         return lut_pz(blz, 0, out retval);
      }
         /* Funktion bank_pz(String blz, out Int32 retval) +���4 */
      static Int32 bank_pz(String blz, out Int32 retval)
      {
         return lut_pz(blz, 0, out retval);
      }
         /* Funktion bank_pz(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_pz(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_pz(blz, zweigstelle, out retval);
      }
         /* Funktion bank_pz(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_pz(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_pz(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_aenderung() +���3 */
#region Funktion bank_aenderung()

         /* ###########################################################################
          * # bank_aenderung(): �nderungskennzeichen einer Bank betimmen (A Addition, #
          * # M Modified, U Unchanged, D Deletion). Gel�schte Datens�tze werden mit   #
          * # dem Kennzeichen 'D' gekennzeichnet und sind - als Hinweis - letztmalig  #
          * # in der Bankleitzahlendatei enthalten. Diese Datens�tze sind ab dem      #
          * # G�ltigkeitstermin der Bankleitzahlendatei im Zahlungsverkehr nicht mehr #
          * # zu verwenden.                                                           #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_aenderung(String blz) +���4 */
      static Int32 bank_aenderung(String blz)
      {
         Int32 retval;
         return lut_aenderung(blz, 0, out retval);
      }
         /* Funktion bank_aenderung(String blz, out Int32 retval) +���4 */
      static Int32 bank_aenderung(String blz, out Int32 retval)
      {
         return lut_aenderung(blz, 0, out retval);
      }
         /* Funktion bank_aenderung(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_aenderung(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_aenderung(blz, zweigstelle, out retval);
      }
         /* Funktion bank_aenderung(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_aenderung(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_aenderung(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_loeschung() +���3 */
#region Funktion bank_loeschung()

         /* ###########################################################################
          * # bank_loeschung(): Hinweis auf eine beabsichtigte Bankleitzahll�schung   #
          * #                                                                         #
          * # Zur fr�hzeitigen Information der Teilnehmer am Zahlungsverkehr und      #
          * # zur Beschleunigung der Umstellung der Bankverbindung kann ein Kredit-   #
          * # institut, das die L�schung einer Bankleitzahl mit dem Merkmal 1 im      #
          * # Feld 2 (Hauptstelle) beabsichtigt, die L�schung ank�ndigen. Die         #
          * # Ank�ndigung kann erfolgen, sobald das Kreditinstitut seine Kunden       #
          * # �ber die ge�nderte Kontoverbindung informiert hat. Es wird empfohlen,   #
          * # diese Ank�ndigung mindestens eine �nderungsperiode vor der              #
          * # eigentlichen L�schung anzuzeigen.                                       #
          * #                                                                         #
          * # Das Feld enth�lt das Merkmal 0 (keine Angabe) oder 1 (BLZ im Feld 1     #
          * # ist zur L�schung vorgesehen).                                           #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_loeschung(String blz) +���4 */
      static Int32 bank_loeschung(String blz)
      {
         Int32 retval;
         return lut_loeschung(blz, 0, out retval);
      }
         /* Funktion bank_loeschung(String blz, out Int32 retval) +���4 */
      static Int32 bank_loeschung(String blz, out Int32 retval)
      {
         return lut_loeschung(blz, 0, out retval);
      }
         /* Funktion bank_loeschung(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_loeschung(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_loeschung(blz, zweigstelle, out retval);
      }
         /* Funktion bank_loeschung(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_loeschung(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_loeschung(blz, zweigstelle, out retval);
      }
#endregion

         /* Funktion bank_nachfolge_blz() +���3 */
#region Funktion bank_nachfolge_blz()

         /* ###########################################################################
          * # bank_nachfolge_blz(): entweder 0 (Bankleitzahl ist nicht zur L�schung   #
          * # vorgesehen, bzw. das Institut hat keine Nachfolge-BLZ ver�ffentlicht)   #
          * # oder eine Bankleitzahl. Eine Bankleitzahl kann nur f�r Hauptstellen an- #
          * # gegeben werden werden, wenn die Bankleitzahl zur L�schung angek�ndigt   #
          * # wurde (bank_loeschung()==1) oder die Bankleitzahl zum aktuellen G�ltig- #
          * # keitstermin gel�scht wird (bank_aenderung()=='D').                      #
          * #                                                                         #
          * # Copyright (C) 2011 Michael Plugge <m.plugge@hs-mannheim.de>             #
          * ###########################################################################
          */

         /* Funktion bank_nachfolge_blz(String blz) +���4 */
      static Int32 bank_nachfolge_blz(String blz)
      {
         Int32 retval;
         return lut_nachfolge_blz(blz, 0, out retval);
      }
         /* Funktion bank_nachfolge_blz(String blz, out Int32 retval) +���4 */
      static Int32 bank_nachfolge_blz(String blz, out Int32 retval)
      {
         return lut_nachfolge_blz(blz, 0, out retval);
      }
         /* Funktion bank_nachfolge_blz(String blz, Int32 zweigstelle) +���4 */
      static Int32 bank_nachfolge_blz(String blz, Int32 zweigstelle)
      {
         Int32 retval;
         return lut_nachfolge_blz(blz, zweigstelle, out retval);
      }
         /* Funktion bank_nachfolge_blz(String blz, Int32 zweigstelle, out Int32 retval) +���4 */
      static Int32 bank_nachfolge_blz(String blz, Int32 zweigstelle, out Int32 retval)
      {
         return lut_nachfolge_blz(blz, zweigstelle, out retval);
      }
#endregion

#endregion
#endregion

      static void Main(string[] args)
      {
         Int32 retval;
         String blz,kto,s,retval_txt;
         string[] s2;

         if (args.Length < 2){
            Console.WriteLine("Aufruf: mini <eingabedatei> <ausgabedatei>");
            Console.ReadLine();
            return;
         }

         kto_check_init();
         StreamReader input = new StreamReader(args[0]);
         StreamWriter output = new StreamWriter(args[1]);

         while ((s = input.ReadLine()) != null) {
            s2 = s.Split(' ');
            blz = s2[0];
            kto = s2[1];
            retval = kto_check_blz(blz, kto);
            retval_txt=retval2txt(retval);
            if (retval >= 0)
               output.WriteLine(blz+" "+kto+": "+retval_txt+"; "
                     + bank_name(blz)
                     + ", " + bank_plz(blz).ToString()
                     + " " + bank_ort(blz));
            else
               output.WriteLine(blz+" "+kto+": "+retval_txt);
         }
         input.Close();
         output.Close();
         kto_check_free();
      }
/* -���2 */
   }
}
